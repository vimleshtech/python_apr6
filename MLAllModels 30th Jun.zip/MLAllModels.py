import pandas  #read file and explore data 

from pandas.tools.plotting import scatter_matrix #graph
import matplotlib.pyplot as plt  #graph 

from sklearn import model_selection #split data in train and test

#Models 
from sklearn.linear_model import LinearRegression 
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
##

##accuracy
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
##

#import data
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class'] #col name

dataset = pandas.read_csv(url,names=cols)
print(dataset.shape) #dimenssion

print(dataset.info())

#row count : 150
#col count : 5 , 4 numeric(float), 1 alpha numeric

#distribuation
print(dataset.groupby('class').size())

print(dataset.groupby('class').max())
print(dataset.groupby('class').min())
print(dataset.groupby('class').sum())

##stats
print(dataset.describe())
#count, mean, min, 25% , 50% , 75%, max


##visual
#dataset.plot() #default is line chart
#plt.show() 

#dataset.plot(kind='bar') #default is line chart
#plt.show()



##

#dataset.plot(kind='box') #default is line chart
#plt.show()


###

# Split-out validation dataset
array = dataset.values #convert data from list
X = array[:,0:4] #get all rows and 4 columns 
Y = array[:,4]  #get all rows in 5 columns

print(X)
print(Y)


X_train, X_validation, Y_train, Y_validation  = model_selection.train_test_split(X, Y, test_size=.20, random_state=7)

print(X_train)
print(X_validation)
print(Y_train)
print(Y_validation)


##model 

models = []
models.append(('a', LogisticRegression()))
models.append(('B', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))



for name, model in models:
	kfold = model_selection.KFold(n_splits=10, random_state=7)
	cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring='accuracy')

	print(name, cv_results.mean(), cv_results.std())
	
	


































