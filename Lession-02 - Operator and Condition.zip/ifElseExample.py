amt = int(input('enter sales amt :'))
tax = 0

if amt > 1000: #true block
     tax =amt*.18
else: #false block 
     tax =amt*.12
     
total = amt + tax
print('total amt :',total)



