#while loop

i =1 # init 
while i<10: #condition 
     print(i)
     i +=1 # increment


#print in reverse
i =10
while i>0:
     print(i)
     i -=1

#print sum of all even and odd numbers between 1 to 100
se = 0
so = 0
i =1
while i<=100:
     if i % 2 ==0:
          se +=i
     else:
          so += i
          
     i +=1

print('sum of all even no :',se)
print('sum of all odd no :',so)





     
