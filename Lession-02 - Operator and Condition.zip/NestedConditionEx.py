a = int(input('enter num value :'))
b = int(input('enter num value :'))
c = int(input('enter num value :'))


if a>b:
     if a>c:
          print(' a is greater')
     else:
          print(' c is greater ')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greate')

#or
if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater')




     




     
          
