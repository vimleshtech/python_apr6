#for

for i in range(1,10): #from 1 to <10 , default incrementer is 1
     print(i)


#in reverse
for i in range(10,0,-1): #from 10 to >0
     print(i)
     
     
