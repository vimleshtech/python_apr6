'''
File Handling: Read and write operation from and with file
There are following functions:
open(path,mode of file)
		path : physical location of file
		mode  : r -read
			w -write  (overwrite the data)
			a - append
			w+ -read and write
			a+ - read and append
read()		: read all content from file 
readline()	: read line by line (first line, 2nd line)
readlines()	: read all lines from from and convert to list
		-every line of file will become one item /element of list
		
write()		: write string to file 
close()		: save and close the file

'''


f = open(r'C:\Users\MAHIMA\Desktop\SAS 9.2\newfile.txt','a')
#f.write('hi this is my first file')
#write multiple line

'''
for i in range(1,5):
    s = input('enter data :')
    f.write(s+'\n')
    
f.close()

print('file is saved')
'''



#read from file
d = open(r'C:\Users\MAHIMA\Desktop\SAS 9.2\newfile.txt')#default is r
#print(d.read())

#print(d.readline())
#print(d.readline())
#print(d.readline())

data = d.readlines()
print(data)

#word count
wc =0

#wap to get count of particular word
pwc =0
for r in data:
    print(r)
    col = r.split(' ')
    wc = wc+len(col)

    for w in col:
        if w =='is':
            pwc =pwc+1
            
d.close()


#get row count from file
print(len(data))

print(wc)

print(pwc)
