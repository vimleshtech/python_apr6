'''
Exception Handling: is also known as error handling

Exception : is runtime error which may or may not occur
Handling  : tackle the error when this will occur

There are following keywords:

try : logical code should be part of try block 
except : catch the error 
pass  : continue the code 
finally  : will run always either exception will occur or not ,
             finally is optional block
raise   : user defined error 

'''


n = int(input('enter data :'))
d = int(input('enter data :'))



try:
    if d<0:
        ex = ZeroDivisionError('divisor cannot be less than 0')
        raise ex
    o = n/d
    print('div ',o)

except NameError as e:
    print(e)

except ZeroDivisionError as er:
    print(er)

except:
    #pass
    print('error in input')

finally:
    print('end of block')
          

o = n+d
print('sum ',o)
