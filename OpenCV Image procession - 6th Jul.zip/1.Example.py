n1 =55
"""
n2 =55

n = n1*n2
"""

#print(n)
