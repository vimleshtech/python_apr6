no1=int(input("Enter a no :"))
print(no1*no1)
