rollNum=int(input("Enter the roll number:"))
name=input("enter the name of student:")

marks_eng1=float(input("enter the student marks in subject english:"))

marks_eng2=float(input("enter the student marks in subject english:"))
marks_eng3=float(input("enter the student marks in subject english:"))
marks_eng4=float(input("enter the student marks in subject english:"))
marks_eng5=float(input("enter the student marks in subject english:"))

total = marks_eng1+marks_eng2+marks_eng3+marks_eng4+marks_eng5

print(total)
avg = total/5
print(avg)


