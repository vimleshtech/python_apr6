n2=int(input("enter the number:"))
print("cube of the number is",n2*n2*n2)
