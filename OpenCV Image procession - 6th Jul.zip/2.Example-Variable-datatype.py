
#here a is variable (temp. memory where data can be stored)
#and 11 is data or value 
a = 11  #int
b = 555.333 #float

c = a+b  #expression / equ.
print(c)  #show result 

print('sum of two numbers :',c)

#datatype
a =44 #int
print(type(a))


a =44.55 #float 
print(type(a))


a ='44' #str
print(type(a))


a ="44-ff"#str 
print(type(a))


a =True #bool
print(type(a))

a =[111,44,555,True,'test'] #list
print(type(a))

a =(111,44,555,True,'test') #tuple
print(type(a))

#dict
a ={1:'one','eid':[1,2,4],'name':['raman','jatin','divya']}
print(type(a))

#set
s = {'iphone','dove','iphone'}
print(type(s))













