amt = int(input('enter amt :'))

tax = 0

if amt>1000:
     tax = amt *.18
     
total = amt+tax
print(total)


##

tax = 0

if amt>1000:
     tax = amt *.18
else:
     tax = amt *.12
total = amt+tax
print(total)

     
