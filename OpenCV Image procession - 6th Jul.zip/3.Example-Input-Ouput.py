
n1 = int(input('enter data :')) #default input type is str 
n2 = int(input('enter data :'))

n = n1+n2

print(n)


