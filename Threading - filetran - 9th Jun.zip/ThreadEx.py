import time
import threading

def p1():
     for x in range(1,5):
          print(x)
          time.sleep(1)
def p2():
     for x in range(11,15):
          print(x)
          time.sleep(1)


t1 = threading.Thread(target=p1,name='process1')
t2 = threading.Thread(target=p2,name='process2')

t1.start()
t2.start()

#p1()
#p2()


##move file
import shutil
#shutil.move(r'C:\Users\vkumar15\Desktop\test.txt',r'C:\Users\vkumar15\Desktop\mylearning')

#read file list from folder or path
import os
files = os.listdir(r'C:\Users\vkumar15\Desktop\mylearning')
print(files)






            




     
