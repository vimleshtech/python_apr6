import time
import threading
import os
import shutil

def p1():
     f=open(r'C:\Users\vkumar15\Desktop\vik\test12.txt','w')
     
     f.close()
def p2():
     files = os.listdir(r'C:\Users\vkumar15\Desktop\vik')
     print(files)
     for i in files:
          if i=='test12.txt':
               e=open(r'C:\Users\vkumar15\Desktop\vik\test12.txt','a')
               s=input('Enter text:-')
               e.write(s)
               shutil.move(r'C:\Users\vkumar15\Desktop\vik\test12.txt',r'C:\Users\vkumar15\Desktop\mylearning')
               e.close()
          else:
               print('no file found')

t1 = threading.Thread(target=p1,name='process1')
t2 = threading.Thread(target=p2,name='process2')


t1.start()
t2.start()






