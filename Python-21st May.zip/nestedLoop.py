for r in range(1,5):    #1 to 4 times
     for c in range(1,5): # 4 times , inner loop will execute for every outer loop
          #4 rows * 4 cols
          print(c)


'''
r=1 c =1 2 3 4
r=2 c =1 2 3 4
r=3 c =1 2 3 4
r=4 c =1 2 3 4
'''

#print in table format
for r in range(1,5):
     for c in range(1,5):
          print(c,end='') #don't change line
     print() #new line 

               
          
