s ='this is test data'
print(s.upper())
print(s.lower())
print(s.title())
print(s.strip())
print(s.replace('a','xy'))
print(s.count('a'))
print(len(s))
print(list(s))
x = s.split(' ')
print(x)


if s.endswith('a'):
     print('string ending with a')

     
