#break
for x in range(1,10):  #from 1 to 3 
     if x % 4 ==0:
          break  #stop the loop 
     print(x)

     
#contiue
for x in range(1,10):  #1 2 3 5 6 7 9 
     if x % 4 ==0:
          continue  #skip the loop
     print(x)

     
     
