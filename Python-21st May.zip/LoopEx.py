#while loop
i =1 #init 
while i<=10: #condition
     print(i,end='') #print and don't change line 
     i=i+1 #steps / increment

#print in reverse
i =10
while i>0:
     print(i) #print and change line 
     i =i-1

#for loop
for x in range(1,11): #from 1 to <11, default incrementer is 1
     print(x)     


#print in reverse
for x in range(10,0,-1): #here -1 is decrementer     
     print(x)
     
