#wap to get count of every value from list 
	#[1,2,1,1,1,2,3,4,5,6]
a=[1,2,1,1,1,2,3,4,5,6]
c=0
for i in a:
    for j in a:
         if a[i]==a[j]:
              c+=1
              print(c)

              
              
     
	
