#empty list
e = []



e.append([1,'nitin','male'])
e.append([2,'raman','male'])
e.append([3,'jatin','male'])
e.append([4,'ayush','male'])
e.append([5,'nitisha','female'])

print(e)


##for r in e:
##     print("hello")
##
##
##for r1 in e[0]:
##     print(r1)
      


print(e[0][1])




 
