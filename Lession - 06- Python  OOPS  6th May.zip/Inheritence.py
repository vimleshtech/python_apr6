class clac:  #parent class

     def add(s,a,b):
          print(a+b)
     def sub(s,a,b):
          print(a-b)



class dcalc(clac):  #child class
     def tax(self,amt):
          t =0
          if amt>1000:
               t = amt*.18
          else:
               t = amt*.10

          print('tax amt is :',t)

     def add(s,a,b):
          print('sum of two num :', a+b)

class dcalc1(clac):  #child class
     def mul(s,a,b):
          print(a*b)
          
#create object of child class
o = dcalc()
o.tax(112334)
o.add(44,5)

          

     
     
     
