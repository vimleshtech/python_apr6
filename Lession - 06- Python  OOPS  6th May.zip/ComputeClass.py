#defined class 
class compute:

     #define functions / methods 
     def set_input(self):  #here self is variable which takes reference of object
          self.a = int(input('enter data :'))  #self.a #declare a as global variable
          self.b = int(input('enter data :'))

     def add_num(s):  #here s is variabel which takes reference of object
          n = s.a+s.b
          print('sum of two numbers ',n)
          
     def sub_num(s):  #here s is variabel which takes reference of object
          n = s.a-s.b
          print('sub of two numbers ',n)

     def __init__(alpha):
          alpha.a = 0
          alpha.b = 0
          print('object is initialized')
          print('there are following functions i. add_num() ii. sub_num() iii. div_num() iv. add(a,b) ')
          
          
     def div_num(s):  #here s is variabel which takes reference of object
          n = s.a/s.b
          print('div of two numbers ',n)

     def __del__(s):
          print(s,' is removed')
          



#create object of class
o = compute()  #create object
#o.set_input()  #invoke /call to function 
o.add_num()
o.sub_num()
#o.div_num()

print(o) #address
          
del o

print(o) #error
o.add_num()


