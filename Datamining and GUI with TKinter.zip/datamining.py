#TEXT MINING

import pandas as pd
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt


data = pd.read_csv(r'C:\Users\vkumar15\Downloads\YouTube-Spam-Collection-v1\Youtube05-Shakira.csv', encoding ="latin-1")
print(data.shape)
print(data.columns)
#['COMMENT_ID', 'AUTHOR', 'DATE', 'CONTENT', 'CLASS']

words =''
for c in data.CONTENT:
     #print(c)
     w = c.split() #by space
     for i in range(0,len(w)):
          w[i] = w[i].lower()

     for s in w:
          words  += s+' '

print(words)

sword = set(STOPWORDS)
print(sword)


wordcloud = WordCloud(width = 700, height = 600, 
                background_color ='lime', 
                stopwords = sword, 
                min_font_size = 12).generate(words)

# plot the WordCloud image                        
plt.figure(figsize = (7, 6), facecolor = None) 
plt.imshow(wordcloud) 
plt.axis("off")  #dont' show x and y axis 
plt.tight_layout(pad = 0) #no space   
plt.show()



     
          
     
     

     
     



