a =11

#if condition 
if a% 2 == 0: #even no
    print('even no')



#if else
if a%2 ==0:
    print('a is even')
else:
    print('a is odd')
    
    

##conditional statementa
a =441
b =443
c = 444
if a>b and a>c:
    print('a is gt')
elif b>a and b>c:
    print(' b is gt')
else:
    print('c is gt')
    


    


    
