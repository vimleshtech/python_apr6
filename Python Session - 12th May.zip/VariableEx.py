#global variable
a = 19 #a is variable and 19 is data or value
print(a)


#define/create function 
#function : is set of command or instructions or unit
def fun_name():    
    print('test code')
    #local variable 
    x =11
    y =444
    print(x+y)
    print('global in function ',a)

#call to function
fun_name()
print(a)
#print(x)

    

