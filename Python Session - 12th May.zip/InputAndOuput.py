a = input('enter data :')
print('data ',a)



d = open(r'C:\Users\Mukesh.Kumar5\Desktop\Python Session - 12th May.txt')
#print(d.read())
#print(d.readline())
#print(d.readlines())

rc =0
for x in d.readlines():
    print(x)
    rc +=1

print('row count ',rc)
    

