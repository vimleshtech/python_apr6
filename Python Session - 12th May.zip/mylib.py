def add(a,b): #here a , b are variable / parameter
    c =a+b
    print('sum of two values ',c)

def tax(sal):
    t = 0
    if sal >10000: #condition 
        t = sal *.20 #true block
    else:
        t = sal *.10 #false block


    print('tax amount is ',t)

def wel():
    print('this module / file contains following functions 1. add(a,b) ii. tax(amt)')

    
    
