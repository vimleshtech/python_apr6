#there are following way to import module
#i .
import mylib

#mylib.wel()
mylib.add(11,233)
mylib.tax(54444)


#ii. with alias
import mylib as m
m.add(33,4)



#iii.
from mylib import * #load all functions
add(11,23)

#iv.
from mylib import add,wel #load few functions
add(1,2)
