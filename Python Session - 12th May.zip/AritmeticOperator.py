#data type and operator
#==========================

a =2
b =5
print(a**b)

print(23/10)
print(23//10)
print(23%10)



a =10
print(a)
a+=1
print(a)


