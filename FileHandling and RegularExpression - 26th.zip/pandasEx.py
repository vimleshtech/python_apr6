import pandas as pd

df = pd.read_csv(r'C:\Users\Tech Vision\Desktop\users.csv')
print(df)

#pd.read_excel(r'C:\Users\Tech Vision\Desktop\users.xlsx',sheet_name='Sheet1')

#dataframe to list
data = df.values
print(data)


#write to csv
df.to_csv(r'C:\Users\Tech Vision\Desktop\users2.csv')
