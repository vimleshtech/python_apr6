f = open (r'C:\Users\Tech Vision\Desktop\users2.txt','a') #default mode is read

for i in range(1,5):
    d = input('enter data :')
    f.write(d+'\n')


f.close()
print('file is saved')


