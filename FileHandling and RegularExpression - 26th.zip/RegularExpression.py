import re

data = input('enter data :')
o = re.match('(.*) are (.*)',data)

if o:
    print('are is match ')
else:
    print('not match')


#email validation
email = input('enter email :')

o = re.search('@gmail.com$',email)
if o:
    print('valid gmail account ')
else:
    print('invalid account ')
    

    

    




