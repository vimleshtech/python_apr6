f = open (r'C:\Users\Tech Vision\Desktop\users.txt') #default mode is read

data = f.readlines()
f.close()

fc =0
mc = 0

for r in data:
    col = r.split(',')
    if col[2] =='male':
        mc+=1
    elif col[2] =='female':
        fc+=1

        
print('male count :',mc)
print('female count :',fc)
    
    
