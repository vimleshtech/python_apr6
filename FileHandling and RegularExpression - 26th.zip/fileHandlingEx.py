f = open (r'C:\Users\Tech Vision\Desktop\MS BI - Day -01 Notes.txt') #default mode is read

#print(f.read())

#print(f.readline())
#print(f.readline())

data = f.readlines()
f.close()

#print(data)

#word count
wc = 0
sc = 0
for r in data:
    #print(r)
    sc += len(r)

    col = r.split(' ')
    wc+=len(col)
    
    
print('char count ',sc)

print('word count ',wc)


    

#row count
print('row count ',len(data))
