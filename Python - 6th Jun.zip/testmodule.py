class test:

     def add(a,b,c):
          print(b+c)
     def mul(a,b,c):
          print('mul of numbers :',b*c)




     
