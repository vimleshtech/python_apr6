class calc:

     def add(a,b,c):
          d =b+c
          print(d)


     #overriding 
     def add(a,b,c,d): #will overlap on above function
          m = b+c+d
          print(m)
          



o = calc()
#o.add(1,2) #error
o.add(4,43,4)
