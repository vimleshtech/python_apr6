inc = 0
#create class
class emp:

     #declare data member
     counter=0
     
     #function or method
     def new_emp(self):  #every function will recevie at least one argument i.e. reference of object
          print('in new_emp function ')
          self.eid =  int(input('enter emp id :'))
          self.ename = input('enter emp name :')
          self.sal = int(input('enter emp basic sal :'))
          self.email = input('enter emp email :')
          self.age = input('enter emp age :')
          self.counter+=1
          self.inc+=1
          

     def cal_sal(self):

          self.hra = self.sal*.40
          self.da = self.sal*.20
          self.msal = self.hra+self.da+self.sal
          self.ysal = self.msal*12
          
          
          
     def disp_emp(self):
          print('in disp emp function')
          print('Employee Details ')
          print(self.eid,self.ename,self.email,self.age,self.msal,self.ysal)
          print(self.inc)
     def __init__(self):
          self.inc=0
          print('object is initialized')
          
          
          
     def __del__(self):  #will call automatically when del wil be invoke 
          print(self,' is removed ')
          
#create object of class
o1 = emp()
#print(o) #print address object
o1.new_emp()
o2 = emp()
o2.new_emp()

o1.cal_sal()
o2.cal_sal()
o1.disp_emp()
o2.disp_emp()

print(o1.counter)


del o1 #remove the memory of o1 object

