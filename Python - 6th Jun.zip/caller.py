from testmodule import test


class test2(test): #exend(inherit) the test class features to test2 class

     def sub(a,b,c):
          print(b-c)




#create an object of child class
o = test2()
o.add(11,22)
o.mul(44,5)
o.sub(55,4)
