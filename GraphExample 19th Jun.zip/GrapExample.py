'''
Matplotlib: is module for data visualization and presntation
pip install matplotlib
'''


import matplotlib.pyplot as plt
import pandas as pd

data = {
     'eid':[100,101,200,140,180],
     'ename':['Monika','Ayush','Nitin','Jyoti','Divya'],     
     'gender':['Female','Male','Male','Female','Female'],
     'salary':[500,400,300,600,100],
     'country':['India','India','UK','India','UK'],
     'exp':[4,3,6,8,2]
     }
df = pd.DataFrame(data)
print(df)

#df.plot() #default is line chart
#df.plot(kind='bar')
#df.plot(kind='box')

#show seperate chart for every numeric column
#df.plot(kind='line',subplots=True) #default in different row

df.plot(kind='line',subplots=True,layout=(2,2)) #per row 2 cols
plt.show()





