a = {'a':'alpha',1:'one','b':'beta','c':300,	101:[1,'raman',True]}


print(a)

print(a['b'])

a['b'] ='alpha'
print(a['b'])

print(a[101])
a[101] =10
print(a[101])

