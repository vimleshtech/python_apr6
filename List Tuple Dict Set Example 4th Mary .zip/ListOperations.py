data = [11,22,3,4,5,2,2,1]

print('max ',max(data))
print('min ',min(data))
print('sum ',sum(data))
print('len ',len(data))

data.append(100)
print(data)


data.pop()
data.pop()
print(data)


if 400 in data:
     data.remove(400)

print(data)

data.sort()
print(data)

#slicer

#-1 :read from right
#0 ..1 : read from left

print(data[-1]) #print last
print(data[1]) #print first element
print(data[1:4]) #range  , from 1 to 3 

#print in reverse
# ::  - read right to left 
print(data[::-1]) #-1   read right to left and decrement by -1


a = [1,2,2,3,4,55]
print(a[3:-1])
print(a[-1::-3])


#dynamic list
d = [] #empty list
for i in range(0,5):
     a = int(input('etner data :'))
     d.append(a)
     
print(d)



     














