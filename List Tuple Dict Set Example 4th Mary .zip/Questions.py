s = input('enter string :')
c = input('enter char to search :')

#C7
'''
if c in s:
     print('given char is matched')
else:
     print('given char is not present')
     
'''

#c8
'''
ismatch = 0

for i in range(0,len(s)):
     if s[i] == c:
          print('matched at position ',i)
          ismatch =1

if ismatch ==0:
     print(0)

'''

#c9
print(s[0:3])











     

          
