data = (11,22,3,4,5,2,2,1)

print('max ',max(data))
print('min ',min(data))
print('sum ',sum(data))
print('len ',len(data))


if 11 in data:
     print('present')
else:
     print('not present')
     

