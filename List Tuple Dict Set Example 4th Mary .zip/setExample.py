a = {'iphone','dove','iphone'}
print(a)
