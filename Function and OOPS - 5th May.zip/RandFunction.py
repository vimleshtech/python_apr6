import random



otp = random.randint(1000,10000)
print(otp)



