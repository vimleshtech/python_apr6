# Example  1 : to import library 
import compute #import python file / module (all functions)

compute.add(1,3)
compute.sub(44,5)



# Example 2 : to import library
from compute import add,sub #import required functions
add(11,2)


# Example 3:
from compute import *  #import all
add(11,2)

# Example 4:
import compute as c
c.add(1,3)








