#define/create function 
def add(a,b):  #here a, and b are argument / paramenter
     c = a+b
     print(c)



#welcome
def ins():
     print('this is modular programing, this file contains following functions')
     print('i. add() ii. ins()')
     

#call to function
add(11,2) #invoke to function 

#ins()

     
