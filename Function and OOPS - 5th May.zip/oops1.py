#class 
class emp:

     __eid__ = 0 #declare data member  , can be use as a global variable

     #function 
     def new_emp(s):
          #print('new emp ',s)
          s.a =3
          s.b =5
          s.id = input('enter id :')
          s.name = input('enter name :')
          s.sal = int(input('enter sal :'))
          
          
     def compute(self):
          self.ysal  = self.sal*12
          

     def show_emp(x):
          #print('show p ',x)
          print(x.a+x.b)
          print('id ',x.id)
          print('name ',x.name)
          print('ysal',x.ysal)
          
     def add(self,a,b):
          print(a+b)
          

#create object
o = emp() #create copy of emp
#print(o)
o.new_emp()
o.compute()
o.show_emp()

o.add(11,23)




     
