def add(a,b):
     c =a+b
     print('sum of two numbers :',c)
     
def sub(a,b):
     c =a-b
     print('sub of two numbers :',c)

def div(a,b):
     c =a/b
     print('div of two numbers :',c)
          
