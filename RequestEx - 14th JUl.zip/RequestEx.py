#https://www.imdb.com/search/title/?release_date=2017&sort=num_votes,desc&page=1
'''
pip install bs4
'''

import requests
from bs4 import BeautifulSoup
o  = requests.get("https://www.yahoo.com")


#response_code : 200 (ok)
#response_code : 400  : client error 
#response_code : 404  : resource is not found
#response_code : 500  : internal server error

print(o)

print(o.status_code)
#print(o.text)
#print(o.content)
page =o.content

html = BeautifulSoup(page,"html.parser")
'''
<html>
<a> ...
</html>

'''

out = html.find_all('a')

print(len(out))
#print(out)
for el in out:
     print(el.getText())
     











