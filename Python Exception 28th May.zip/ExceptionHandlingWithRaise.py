#Python Code: for exception handling

n = int(input('enter data :'))
d = int(input('enter data :'))


try:
     #division
     if d<0:
          e = ZeroDivisionError('divisor cannot be less than 0')
          raise e
     o = n/d
     print('division of numbers :',o)

except ZeroDivisionError as er:
     print(er)
     
except:
     print('there is error , plz check your input')
     pass  #continue the code
     
#addition
o = n+d
print('sum of numbers :',o)






