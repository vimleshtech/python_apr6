#Python Code: for exception handling

n = int(input('enter data :'))
d = int(input('enter data :'))


try:
     #division 
     o = n/d
     print('division of numbers :',o)

except ZeroDivisionError as er:
     print(er)
     
except NameError as er:
     print(er)
     
except:
     print('there is error , plz check your input')
     pass  #continue the code
     
finally:
     print('end of block')  #this statement will execute either error will occur or not
     
     

#addition
o = n+d
print('sum of numbers :',o)






