import re
f = open(r'C:\Users\vkumar15\Desktop\Weekend - Sessions\DockerSession.txt')

data = f.readlines()  #data type of data is lsit

for r in data:
     #print(r)
     o = re.search('(.*) is (.*)',r)
     if o:
          print(r)
          
     

