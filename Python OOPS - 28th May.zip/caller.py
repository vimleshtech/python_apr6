from module2 import dcal

o = dcal()
o.add(444,3)
o.tax(4444)
