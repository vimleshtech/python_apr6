from  module1 import cal


class dcal(cal): #inheritence

     def mul(s,a,b):
          m = a*b
          print(m)



     def tax(s,amt):
          a = amt*.18
          print(a)
          

     
