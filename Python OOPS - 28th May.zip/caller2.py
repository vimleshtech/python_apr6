from module3 import taxcalc
o = taxcalc()
o.gst(1133)
o.add(1133,444)
o.mul(1133,444)
