class A:
     def add(s,a,b):
          print(a+b)
          
class B:
     def sub(s,a,b):
          print(a-b)

class C(A,B): #Multiple  -multiple parent one child 
     def mul(s,a,b):
          print(a-b)



class D(A):  #ine parent multiple child 
     def dd(s):
          print('in D')
class M(A):
     def mm(s):
          print('in mm')
     

o = C()
o.add(4,4)
o.sub(44,5)
o.mul(44,5)



od = D()
od.add(44,4)
od.dd()





