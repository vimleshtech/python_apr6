

class test:

     def add(s,a,b):
          m = a+b
          print(m)

     def __del__(s):
          print(s, 'is removed')

     def add(s,a,b,c): #add(three argument) will overwrite to above add(two argument function)
          x = a+b+c
          print(x)
          
#object
o = test()
#o.add(21,3)  #cannot be call
o.add(21,6,32)

del o #remove object

