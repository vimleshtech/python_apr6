from module2 import dcal
class taxcalc(dcal):
     def gst(s,amt):
          g = amt*.05
          print(g)
          
