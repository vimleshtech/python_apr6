class cal:

     def add(s,a,b):
          print(a+b)

     def sub(s,a,b):
          print(a-b)




