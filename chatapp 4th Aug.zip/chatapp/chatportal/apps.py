from django.apps import AppConfig


class ChatportalConfig(AppConfig):
    name = 'chatportal'
