from django.shortcuts import render

from django.http import HttpResponse 
from django.shortcuts import render_to_response 

# Create your views here.

def index(request):
    #return HttpResponse("Hi, this is my first app ")
    #return HttpResponse("Name :<input type='text' /> Email :<input type='text' /> Mobile :<input type='text' /> <input type='button' value='clikc' />")
    return render_to_response("chatportal/index.htm")




def save(request):

    name = request.GET['name']
    email = request.GET['email']
    phone = request.GET['phone']

    return HttpResponse("you have entered "+name)    

