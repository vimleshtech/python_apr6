from django.urls import path,include
from . import views #. current dir 

urlpatterns = [
    path('save',views.save,name='save'),
    path('',views.index,name='index'), #'' landing /first page

]





