#Example  -2
a = float( input('enter data :'))
b = float( input('enter data :'))
        

print(type(a))
print(type(b))


c = a+b
print('sum of two values ',c)
        
