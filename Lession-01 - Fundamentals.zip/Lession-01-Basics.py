# Example  -1

name ="nitin"  # str

a =1  # int
b =44 # int

c =a+b # expression /logic

print(c) #show output
print(name)




