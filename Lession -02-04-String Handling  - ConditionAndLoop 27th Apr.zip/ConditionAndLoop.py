#condition : is decision making statement

a =110
b =44

#show greater no
if a>b:
     print('a is gt')
else:
     print('b is gt')
     


#
a=1
b =4
c =66
if a> b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
elif c>a and c>b:
     print('c is gt')
else:
     print('few or all are equal')
     
           
     
