#loop : is iterator or repeation of statement
#types : i. while loop

i = 1 #init / start from 
while i<10: #conditon
     print(i)
     i =i+1  #incrementer
     

#print in reverse
i =10
while i>0:
     print(i)
     i =i-1
     

#ii. for loop
for i in range(1,10): #from 1 to <10, default incrementer is 1
     print(i)


#in reverse
for i in range(10,0,-1):
     print(i)
     
     

for i in range(10,0,-2):
     print(i)
     

#
a = 'this IS TeSt'

for c in a:
     #print(c)
     if c.islower():
          print(c.upper(),end='')
     else:
          print(c.lower(),end='')
               


          
     





