'''
     string  handling:
          upper()   -return in upper case
          lower()   -return in lower case
          title()   -return in proper case
                          thi is  = This Is
          strip()   -remove the leading space(before and after)
          replace() -find existing char and replace with new
          len(arg)     -return count of chars/digits
          list(arg)    -convert to list
                      'this is' = 't','h','i','s',' ','i','s'

          count('a') -return count for given value
          split(sep/delimeter) -  break the string by given seperator
                         Raman Kumar Sinha
                                   = Raman
                                   = Kumar
                                   = Sinha
          slicer    - return value by given index
                       a = 'Nitin Sharma'
                       a[1:3] = it  , from 1 to <3
          
          islower()   - return true if given value in lower case
          isupper()   - return true if given value in upper case
          
          endswith()   -match the given char at last
          
'''

name = input('enter name :')

l = len(name)
print(l)


u = name.upper()
print(u)

print(name.lower())

print(name.title())
print(name.strip())


d = list(name)
print(d)


c = name.count('a')
print(c)



s = name.split(' ')
print(s)

#slicer
#:: - read right to left , -1 decrement by -1


x ='a'

if x.islower():
     print('in lower case')
else:
     print('upper case ')



if x.isupper():
     print('in upper case')
else:
     print('lower case ')


if name.endswith('n'):
     print('end with n')
else:
     print('not end with n')

     


a = name.replace('a','xy' )
print(a)
