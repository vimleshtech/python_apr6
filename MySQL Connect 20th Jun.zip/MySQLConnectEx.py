import mysql.connector as c

#establish the connection
con = c.connect(host='localhost',user='root',password='root',database='testdb')

#create object of cursor , cursor can execute sql command
cur = con.cursor()

def read_data():
     cur.execute('select * from users') #execute sql command


     #print(cur.fetchall()) #fetch data from cur object

     data =cur.fetchall()
     for r in data:
          print(r[1])
          

def write_data():
     cur.execute("insert into users(uid,name) values(10,'ayush')") #execute sql command
     con.commit() #save database/ transaction commit

def del_data():
     cur.execute("delete from users where uid =10") #execute sql command
     con.commit() #save database/ transaction commit



write_data()
read_data()




     
          


