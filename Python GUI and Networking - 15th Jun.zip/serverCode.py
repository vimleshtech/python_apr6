import socket
import random


s = socket.socket()
host = socket.gethostname() 
port = 1234 #from 2 to 6 digit any unique number

s.bind((host,port))
print('server is started')


s.listen(10)

while True:
     c,add = s.accept()  #object ref and content , address is client ip
     print(c)
     print('Thank for calling me, got request from client ',add)

     n = random.randint(1000,9999)
     
     
     c.send(('OTP is : '+str(n)).encode())
     c.close()
     

     
     
     



