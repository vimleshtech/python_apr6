from tkinter import *

o = Tk()

l1 = Label(text='GUI Application - Example')
l1.pack()

lfn = Label(text='Enter First Name')
lfn.pack()

tfn = Entry()
tfn.pack()




lln = Label(text='Enter Last Name')
lln.pack()

tln = Entry()
tln.pack()

lblmsg = Label(text='')
lblmsg.pack()

def ab():
     print('you have clicked on save button!!!!')
     fn = tfn.get()
     ln = tln.get()
     full_name = fn+' '+ln
     print('first name {} and last name is {} , complete name {}  '.format(fn,ln,full_name))
     lblmsg.configure(text=full_name)
     
btn = Button(text='Save',command=ab)
btn.pack()


o.mainloop()


