import mysql.connector as con

#establish the connection from python to db
c = con.connect(host='localhost',user='root',password='root',database='dblearning')
cur = c.cursor()

def read_data():
     cur.execute('select * from users')

     o = cur.fetchall()

     for r in o:
          #print(r)
          print(r[0], r[1])
     

def write_data():
     cur.execute("insert into users(uid,name,email,pwd) values(1,'raman','raman@gmail.com','test12');")
     c.commit() #save
     print('data is saved to databse table')
     

write_data()
read_data()



