from django.shortcuts import render,render_to_response 
from django.http import HttpResponse

# Create your views here.
def index(request):
    #return HttpResponse("<textarea> </textarea ><input type='button' value='Send' /> <a href='http://127.0.0.1:8000/about'> About Us </a> | <a href='http://127.0.0.1:8000/home'> Home </a> |  <a href='http://127.0.0.1:8000'> Index </a>")
    return render_to_response('chatdemo/index.html')

def home(request):
    #return HttpResponse("home page. <a href='http://127.0.0.1:8000/about'> About Us </a> | <a href='http://127.0.0.1:8000/home'> Home </a> |  <a href='http://127.0.0.1:8000'> Index </a>")
    return render_to_response('chatdemo/home.html')

def about(request):
    #return HttpResponse("about me <a href='http://127.0.0.1:8000/about'> About Us </a> | <a href='http://127.0.0.1:8000/home'> Home </a> |  <a href='http://127.0.0.1:8000'> Index </a>")
    return render_to_response('chatdemo/about.html')


def save_data(request):

    fn = request.GET['fname']
    ln = request.GET['lname']
    email = request.GET['email']
    password = request.GET['password']
    phone = request.GET['phone']
    dob = request.GET['dob']

    f = open('users.txt','a')
    f.write(fn+','+ln+','+email+','+password+','+phone+','+dob)
    f.write('\n')
    f.close()
    
    return HttpResponse("you have clicked on button "+fn)


