from django.apps import AppConfig


class ChatdemoConfig(AppConfig):
    name = 'chatdemo'
