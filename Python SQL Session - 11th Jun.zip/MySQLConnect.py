import mysql.connector as c

#connecto db server
con = c.connect(host='localhost',user='root',password='root',database='python_sample')

#create objec to cursor class to execute sql command in python
cur = con.cursor()

def read_data():
     cur.execute('select * from employee')

     out = cur.fetchall()
     #print(out)
     #sum of salary
     sal =0
     for r in out:
          #print(r)
          print(r[1],r[2])
          sal = sal+r[3]

     print('total salary :',sal)
          
def write_data():
     cur.execute("insert into employee values(100,'Nitisha','Female',90000)")
     con.commit() #transaction save to database


write_data()
read_data()






     




     
