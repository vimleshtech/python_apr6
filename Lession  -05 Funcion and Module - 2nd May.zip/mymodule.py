#no argument no return
def wel():
     print('welcome... to fun world !!!!')


#no argument with return
def get():
     a = int(input('enter data :'))
     b = int(input('enter data :'))
     return a,b #here a and b are local variable (cannot be access outside from function)


#argument with no return

'''     
def add(a,b,c):
     x =a+b+c
     print(x)
'''
def add(a,b,c=0,d=0): #function with default argument
     c =a+b+c+d
     print('sum of two valeus :',c)

     
#argument with return
def mul(a,b):
     c  = a*b
     return c


#function with dynamic argument
def mul(*a):
     print(a)
     print(type(a))
     o =1
     for x in a:
          o *=x

     print('output is ',o)
     

