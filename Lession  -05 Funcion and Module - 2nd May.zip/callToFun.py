#no argument no return
def wel():
     print('welcome... to fun world !!!!')


#no argument with return
def get():
     a = int(input('enter data :'))
     b = int(input('enter data :'))
     return a,b #here a and b are local variable (cannot be access outside from function)


#argument with no return

'''     
def add(a,b,c):
     x =a+b+c
     print(x)
'''
def add(a,b,c=0,d=0): #function with default argument
     c =a+b+c+d
     print('sum of two valeus :',c)

     
#argument with return
def mul(a,b):
     c  = a*b
     return c


#function with dynamic argument
def mul(*a):
     print(a)
     print(type(a))
     o =1
     for x in a:
          o *=x

     print('output is ',o)
     

#recursive function
def fact(n):
     if n ==1:
          return n
     else:
          return n*fact(n-1)
     

#lambda
tax18 = lambda x: x * .18

def tax(x):
     t = x*.18
     return t


print(tax18(10000))




#call to fun
wel()
wel()

x,y = get()
#print(x+y)
add(x,y)
add(x,y,33)
add(x,y,55,6)
#add(11,22,3)


o = mul(11,3)
print(o)

mul(1,32)
mul(1,32,454,43,3,3,3,3,4,5)
mul(1,32,4,3,23,2,2,2,3,3,4,4,45,56,6,4,4,34,3,3)

a = fact(5)
print(a)


