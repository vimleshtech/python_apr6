
import numpy as np
l = [111,222,33,4,5]
print(l)
print(type(l))

o = np.array(l)
print(o)
print(type(o))

print(o*2)
print(o*1.18)

o = np.zeros(10)
print(o)


o = np.ones(10)
print(o)

#arange
d = np.arange(1,100)  #from/start , to/stop 
print(d)


d = np.arange(1,100,5) #start , stop, increment by 
print(d)


###2 D
x = np.array([[1,2,3],[4,5,6],[6,7,8]])
y = x*3




print(x)
print(y)


###add two array of 2 D

print(np.add(x,y))
print(np.subtract(x,y))
print(np.divide(x,y))
print(np.multiply(x,y))


#transpose
print(x.T)


##datatype
l = [111,222,33.44,4.33,5]

o = np.array(l,dtype=float)
print(o)

##
print(o.shape)
print(x.shape)


#reshape
a = [1,2,3,4,5,6,7,8,9]


aa = np.array(a)
print('one dimenssion : ',aa)

aa= aa.reshape([3,3])
print('two dimensssion -after reshape :',aa)

















