import pandas as pd

#create empty dataframe
df = pd.DataFrame()
print(df)

#convert list to dataframe
eid = [11,222,33,44,5]
ename = ['Raman','Nitin','Monika','Jatin','Divya']
gender = ['M','N','F','M','F']
sal = [40000,67000,22000,98000,80000]
exp = [4,5,2,8,7]

emp = pd.DataFrame(data={'empid':eid,'name':ename,'gender':gender,'salary':sal,'exp':exp})
print(emp)

#show dimenssion 
print(emp.shape)
#show columns
print(emp.columns)

#rename column
emp.columns=['Employee Code','Employee Name','Sex','Salary','exp']
print(emp)

#show particular column
print(emp['Employee Name'])

#show selected columns
print(emp[['Employee Name','Sex','Salary']])

#show top rows  from dataframe
print(emp.head(2))

#from buttom
print(emp.tail(3))

#info
print(emp.info())


#Distribuation or group by
print(emp.groupby('Sex').size())
print(emp.groupby('Sex').count())
print(emp.groupby('Sex').sum())
print(emp.groupby('Sex').max())
print(emp.groupby('Sex').min())


print(emp.groupby('Sex').sum()['Salary'])


#order by : sort data
print(emp.sort_values('Salary',ascending=True))
print(emp.sort_values('Salary',ascending=False))
print(emp.sort_values('Employee Name',ascending=True))


###stats
print(emp.describe())


##corr
print(emp.corr())







































