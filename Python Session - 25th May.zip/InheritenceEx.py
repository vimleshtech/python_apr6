class calc:
     def add(s,a,b):
          print(a+b)


     def sub(s,a,b):
          print(a-b)


#o = calc()
#o.add(11,2)
#o.sub(44,5)


