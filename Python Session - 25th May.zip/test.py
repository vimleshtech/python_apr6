a=1
 server='fff'
s='ffff

