class compute:

     def __init__(s):
          print(s ,' object is created ')
          s.sid =0
          s.name =''
          s.sal =0
          
     def show(s):
          print('test print')
          print('id is ',s.sid)
          print('name is ',s.name)
          print('sal  is ',s.sal)
     def __del__(s):
          print('object is removed, now you cannot use further ')

     def add(s,a,b):
          print(a+b)
          
     def add(s,a,b,c):
          print(a+b+c)
          
     

#create object of class compute
o = compute()
o.show()
o.add(1,3,4)


del o #delete the object
#o.show()





          
