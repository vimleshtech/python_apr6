class test1:

     def add(s,a,b):
          print(a+b)
          
     class test2:

          def sub(s,a,b):
               print(a-b)



o = test1()
o.add(11,3)

d = o.test2()
d.sub(11,3)





               

          
