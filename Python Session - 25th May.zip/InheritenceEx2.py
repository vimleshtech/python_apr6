from InheritenceEx import  calc

class dcalc(calc):

     def tax(s,amt):
          t = amt*.18
          print(t)



o = dcalc()
o.add(1,344)
o.tax(44556)


     


