y =10 #global
a =10

def test():
     a =1  #private / local 
     print(a) #1
     print(10)
     print(m)
     



m =10 #global 
test()
print(a) #10


     

