''''
Regression Model:  to show the intercept and coficeint between x and
     x: input / independent variable
     y: output / dependent variable / response
     Eq:
               y~x

               
     Example:
              x/study_hours =[6,8,6,12,7]
              y/score    =[56,76,62,94,64]


     Types of Regression Model:
               - Linear Regression model
                    one independent ane one dependent
                    y  ~ x

                    Example1: get co-relation between marks/score and study hours
                    Example2: get how weight is depends on height
                    
                          
               - Multiple Regression model
                    multiple independent and one dependent
                    y ~ x1+ x2+x3 ......
                    mpg~ hp+cyl+weight...

                    Example 1: get how car mpg is depends on hp,cyl,weight,width


Implementation:
Step 1:
     import numpy
     import sklearn  


Step 2: load or read data or prepare data
     x : should be 2 Dimenssional array
     y : one dimenssion array

Step 3: Prepare train , and test/validation data
     Train data: historical data
     Test data : is new dataset or data to be valdiated 

'''

import numpy as np
from sklearn.linear_model import LinearRegression # is class


#train data 
height =[140,155,156,134,143,149]
height = np.array(height).reshape((-1, 1))  #convert list to array and then reshape to two dimenssion array 
print(height)

weight =[51,62,72,45,52,56]
weight = np.array(weight)
print(weight)



reg = LinearRegression()
reg.fit(height,weight)  #get the relation


print('coefficient of determination:', reg.score(height, weight))
print('intercept:', reg.intercept_)


#new data
nh = []
for r in range(5):
     h = int(input('enter height :'))
     nh.append(h)


print(nh)

nheight = np.array(nh).reshape((-1, 1))
print(nheight)


y_new = reg.predict(nheight)
print(y_new) #print predicted data













                    

               
     
