#dynamic list example
a = [] #declare empty list

for x in range(1,5): #read 4 element from user and stor in list
     d = int(input('enter data :'))
     a.append(d)


#print all
print(a)

#print one by one
for e in a:
     print(e,end=' ')
     


