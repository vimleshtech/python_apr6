a =[111,2,2,3,4,4,5,6,3,3,3,4]

print(len(a))
print(max(a))
print(min(a))
print(sum(a))

print(a)

a.append(100)
print(a)

a.pop()
print(a)

a.insert(1,300)
print(a)

a.remove(300)
print(a)

a.sort()
print(a)
print(a[::-1])
print(a[::-2])




