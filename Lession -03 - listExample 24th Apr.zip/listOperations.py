data = [] #declare empty list

#CRUD : Create , read, update, delete

while True:
     ch = input('enter 1 for create 2 for read 3 for update 4 for delete 0 for exit ')
     
     if ch =='1':
          d = int(input('enter data  :'))
          data.append(d)
     elif ch =='2':
          print(data)

     elif ch =='3':
          i =int(input('enter index which u want to modify :'))
          d = int(input('enter new data :'))

          if i>-1 and  i < len(data):
               data[i] = d
               print('data is modifed')
          else:
               print('out of index')
               
          
     elif ch =='4':
          d = int(input('enter data  to remove :'))
          if d in data:
               data.remove(d)
               print('given value is removed')
          else:
               print('given value not found')
          
     elif ch =='0':
          break 
     else:     
          print('invalid choice , plz try again !!!')
          
